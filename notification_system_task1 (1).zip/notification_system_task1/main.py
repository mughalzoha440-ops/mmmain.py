"""OOP Notification System - Task 1.

Delivery is simulated for assessment purposes; no real messages are sent.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import re
from typing import Any


class NotificationStatus(str, Enum):
    PENDING = "PENDING"
    SENT = "SENT"
    FAILED = "FAILED"


@dataclass
class Notification(ABC):
    notification_id: int
    recipient: str
    message: str
    fail_attempts: int = 0
    status: NotificationStatus = NotificationStatus.PENDING
    attempts: int = 0
    created_time: datetime = field(default_factory=datetime.now)
    history: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.recipient or not self.recipient.strip():
            raise ValueError("Recipient cannot be empty.")
        if not self.message or not self.message.strip():
            raise ValueError("Message cannot be empty.")
        if self.fail_attempts < 0:
            raise ValueError("fail_attempts cannot be negative.")
        self.validate_recipient()
        self.history.append(f"{self.timestamp}: Notification created ({self.channel_name}).")

    @property
    @abstractmethod
    def channel_name(self) -> str:
        pass

    @abstractmethod
    def validate_recipient(self) -> None:
        pass

    @abstractmethod
    def build_payload(self) -> dict[str, Any]:
        pass

    @property
    def timestamp(self) -> str:
        return self.created_time.strftime("%Y-%m-%d %H:%M:%S")

    def send(self) -> bool:
        """Simulate one delivery attempt. Return True only when sent."""
        self.attempts += 1
        if self.attempts <= self.fail_attempts:
            self.status = NotificationStatus.FAILED
            result = f"Attempt {self.attempts}: delivery failed (simulated)."
        else:
            self.status = NotificationStatus.SENT
            result = f"Attempt {self.attempts}: delivery successful (simulated)."
        self.history.append(f"{datetime.now():%Y-%m-%d %H:%M:%S}: {result}")
        return self.status == NotificationStatus.SENT

    def retry(self) -> bool:
        if self.status != NotificationStatus.FAILED:
            raise ValueError("Only failed notifications can be retried.")
        self.history.append(f"{datetime.now():%Y-%m-%d %H:%M:%S}: Retry requested.")
        return self.send()

    def get_details(self) -> dict[str, Any]:
        return {
            "notification_id": self.notification_id,
            "channel": self.channel_name,
            "recipient": self.recipient,
            "message": self.message,
            "status": self.status.value,
            "attempts": self.attempts,
            "created_time": self.timestamp,
        }


class EmailNotification(Notification):
    @property
    def channel_name(self) -> str:
        return "Email"

    def validate_recipient(self) -> None:
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", self.recipient.strip()):
            raise ValueError("Invalid email address.")

    def build_payload(self) -> dict[str, Any]:
        return {"to": self.recipient, "subject": "Notification", "body": self.message}


class SMSNotification(Notification):
    @property
    def channel_name(self) -> str:
        return "SMS"

    def validate_recipient(self) -> None:
        if not re.fullmatch(r"\+?[0-9]{7,15}", self.recipient.strip()):
            raise ValueError("Invalid phone number. Use 7 to 15 digits, optionally starting with +.")

    def build_payload(self) -> dict[str, Any]:
        return {"to": self.recipient, "text": self.message}


class WhatsAppNotification(Notification):
    @property
    def channel_name(self) -> str:
        return "WhatsApp"

    def validate_recipient(self) -> None:
        if not re.fullmatch(r"\+?[0-9]{7,15}", self.recipient.strip()):
            raise ValueError("Invalid WhatsApp number. Use 7 to 15 digits, optionally starting with +.")

    def build_payload(self) -> dict[str, Any]:
        return {"messaging_product": "whatsapp", "to": self.recipient, "type": "text",
                "text": {"body": self.message}}


class WebhookNotification(Notification):
    @property
    def channel_name(self) -> str:
        return "Webhook"

    def validate_recipient(self) -> None:
        if not re.match(r"^https?://[^\s]+$", self.recipient.strip()):
            raise ValueError("Webhook recipient must be a valid HTTP or HTTPS URL.")

    def build_payload(self) -> dict[str, Any]:
        return {"event": "notification", "notification_id": self.notification_id,
                "message": self.message, "created_time": self.timestamp}


class NotificationService:
    CHANNELS = {
        "email": EmailNotification,
        "sms": SMSNotification,
        "whatsapp": WhatsAppNotification,
        "webhook": WebhookNotification,
    }

    def __init__(self) -> None:
        self.notifications: list[Notification] = []
        self._next_id = 1

    def create_notification(self, channel: str, recipient: str, message: str,
                            fail_attempts: int = 0) -> Notification:
        channel_key = channel.strip().lower()
        notification_class = self.CHANNELS.get(channel_key)
        if notification_class is None:
            raise ValueError("Invalid channel. Choose Email, SMS, WhatsApp, or Webhook.")
        notification = notification_class(
            notification_id=self._next_id,
            recipient=recipient,
            message=message,
            fail_attempts=fail_attempts,
        )
        self.notifications.append(notification)
        self._next_id += 1
        return notification

    def send_notification(self, notification_id: int) -> bool:
        notification = self.get_notification(notification_id)
        if notification.status != NotificationStatus.PENDING:
            raise ValueError("Only pending notifications can be sent. Use retry for failed notifications.")
        return notification.send()

    def retry_notification(self, notification_id: int) -> bool:
        return self.get_notification(notification_id).retry()

    def get_notification(self, notification_id: int) -> Notification:
        for notification in self.notifications:
            if notification.notification_id == notification_id:
                return notification
        raise ValueError(f"Notification ID {notification_id} was not found.")

    def get_all_notifications(self) -> list[Notification]:
        return self.notifications.copy()

    def get_history(self, notification_id: int) -> list[str]:
        return self.get_notification(notification_id).history.copy()


def print_notification(notification: Notification) -> None:
    details = notification.get_details()
    print("\n" + "-" * 45)
    for key, value in details.items():
        print(f"{key.replace('_', ' ').title()}: {value}")
    print("-" * 45)


def run_cli() -> None:
    service = NotificationService()
    while True:
        print("\n===== NOTIFICATION SYSTEM =====")
        print("1. Create and send notification")
        print("2. View all notifications")
        print("3. Check notification status")
        print("4. Retry failed notification")
        print("5. View notification history")
        print("6. Exit")
        choice = input("Enter choice (1-6): ").strip()

        try:
            if choice == "1":
                print("Channels: Email, SMS, WhatsApp, Webhook")
                channel = input("Enter channel: ")
                recipient = input("Enter recipient (email / phone / webhook URL): ")
                message = input("Enter message: ")
                fail_attempts_text = input("Simulate how many initial failures? (0 for none): ").strip() or "0"
                fail_attempts = int(fail_attempts_text)
                if fail_attempts < 0:
                    raise ValueError("Failure count cannot be negative.")
                notification = service.create_notification(channel, recipient, message, fail_attempts)
                print(f"Created notification ID: {notification.notification_id}")
                sent = service.send_notification(notification.notification_id)
                print("Notification sent successfully." if sent else "Notification failed. You can retry it.")
                print_notification(notification)
            elif choice == "2":
                notifications = service.get_all_notifications()
                if not notifications:
                    print("No notifications found.")
                for notification in notifications:
                    print_notification(notification)
            elif choice == "3":
                notification_id = int(input("Enter notification ID: "))
                print_notification(service.get_notification(notification_id))
            elif choice == "4":
                notification_id = int(input("Enter failed notification ID: "))
                sent = service.retry_notification(notification_id)
                print("Retry successful." if sent else "Retry failed. You may try again.")
                print_notification(service.get_notification(notification_id))
            elif choice == "5":
                notification_id = int(input("Enter notification ID: "))
                history = service.get_history(notification_id)
                print("\n--- Notification History ---")
                for entry in history:
                    print(entry)
            elif choice == "6":
                print("Thank you for using the Notification System.")
                break
            else:
                print("Invalid choice. Please enter a number from 1 to 6.")
        except ValueError as error:
            print(f"Error: {error}")


if __name__ == "__main__":
    run_cli()
