# OOP Notification System — Task 1

A command-line Object-Oriented Programming project that manages Email, SMS, WhatsApp, and Webhook notifications.

> **Important:** Delivery is simulated. This project does not connect to real email, SMS, WhatsApp, or webhook services.

## Features

- Create notifications through four channels: Email, SMS, WhatsApp, and Webhook
- Validate email addresses, phone numbers, webhook URLs, and message content
- Track notification IDs, channel, recipient, message, status, attempts, and creation time
- Simulate delivery success and failure
- Retry failed notifications
- View all notifications, individual status, and notification history
- Unit tests using Python's built-in `unittest` module

## Project files

- `main.py` — classes, service logic, and command-line interface
- `test_main.py` — automated unit tests
- `README.md` — project documentation
- `.gitignore` — files excluded from Git

## Requirements

- Python 3.10 or newer
- No third-party packages required

## Run the application

```bash
python main.py
```

Follow the menu and enter a number from 1 to 6. When creating a notification, enter `0` for no simulated failures. Enter a positive number to simulate that many initial failed attempts; retrying after those failures will succeed.

## Run tests

```bash
python -m unittest -v
```

## OOP concepts used

- **Abstraction:** `Notification` is an abstract base class defining the common notification interface.
- **Inheritance:** `EmailNotification`, `SMSNotification`, `WhatsAppNotification`, and `WebhookNotification` inherit from `Notification`.
- **Encapsulation:** Notification data and behavior are grouped inside classes; `NotificationService` manages notification records.
- **Polymorphism:** Each channel implements its own recipient validation and payload-building behavior.

## Data structures and complexity

Notifications are stored in a Python list.

| Operation | Time complexity | Explanation |
|---|---:|---|
| Create notification | O(1) average | Appending to a list and assigning an ID |
| Get all notifications | O(n) | Copying/visiting the list |
| Find notification by ID | O(n) | Linear search through notifications |
| Get history | O(n) | Finding the notification is O(n); copying its history is O(h) |
| Add history entry | O(1) amortized | Appending to a list |

Here, `n` is the number of notifications and `h` is the number of history entries for one notification.

## Possible future improvements

Real provider integrations, persistent database storage, authentication, and configurable retry limits could be added in a future version.
