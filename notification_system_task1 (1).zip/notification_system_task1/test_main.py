import unittest

from main import (
    EmailNotification,
    NotificationService,
    NotificationStatus,
    SMSNotification,
    WhatsAppNotification,
    WebhookNotification,
)


class TestNotificationSystem(unittest.TestCase):
    def setUp(self):
        self.service = NotificationService()

    def test_create_email_notification(self):
        item = self.service.create_notification("email", "zoha@example.com", "Hello")
        self.assertIsInstance(item, EmailNotification)
        self.assertEqual(item.status, NotificationStatus.PENDING)

    def test_create_sms_notification(self):
        item = self.service.create_notification("sms", "+923001234567", "Hello")
        self.assertIsInstance(item, SMSNotification)

    def test_create_whatsapp_notification(self):
        item = self.service.create_notification("whatsapp", "+923001234567", "Hello")
        self.assertIsInstance(item, WhatsAppNotification)

    def test_create_webhook_notification(self):
        item = self.service.create_notification("webhook", "https://example.com/hook", "Hello")
        self.assertIsInstance(item, WebhookNotification)
        self.assertEqual(item.build_payload()["event"], "notification")

    def test_invalid_channel(self):
        with self.assertRaises(ValueError):
            self.service.create_notification("fax", "1234567890", "Hello")

    def test_empty_message(self):
        with self.assertRaises(ValueError):
            self.service.create_notification("email", "zoha@example.com", "   ")

    def test_invalid_email(self):
        with self.assertRaises(ValueError):
            self.service.create_notification("email", "not-an-email", "Hello")

    def test_send_successfully(self):
        item = self.service.create_notification("email", "zoha@example.com", "Hello")
        self.assertTrue(self.service.send_notification(item.notification_id))
        self.assertEqual(item.status, NotificationStatus.SENT)

    def test_failure_then_retry_success(self):
        item = self.service.create_notification("sms", "+923001234567", "Hello", fail_attempts=1)
        self.assertFalse(self.service.send_notification(item.notification_id))
        self.assertEqual(item.status, NotificationStatus.FAILED)
        self.assertTrue(self.service.retry_notification(item.notification_id))
        self.assertEqual(item.status, NotificationStatus.SENT)
        self.assertEqual(item.attempts, 2)

    def test_retry_non_failed_notification(self):
        item = self.service.create_notification("email", "zoha@example.com", "Hello")
        self.service.send_notification(item.notification_id)
        with self.assertRaises(ValueError):
            self.service.retry_notification(item.notification_id)

    def test_notification_history(self):
        item = self.service.create_notification("email", "zoha@example.com", "Hello")
        self.service.send_notification(item.notification_id)
        history = self.service.get_history(item.notification_id)
        self.assertGreaterEqual(len(history), 2)
        self.assertIn("successful", history[-1])

    def test_unique_ids(self):
        first = self.service.create_notification("email", "a@example.com", "One")
        second = self.service.create_notification("email", "b@example.com", "Two")
        self.assertNotEqual(first.notification_id, second.notification_id)

    def test_unknown_notification_id(self):
        with self.assertRaises(ValueError):
            self.service.get_notification(999)


if __name__ == "__main__":
    unittest.main(verbosity=2)
